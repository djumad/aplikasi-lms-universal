<div class="h-screen overflow-y-scroll snap-y snap-mandatory">
    <section class="h-screen snap-start">
        <?php if (isset($component)) { $__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5 = $attributes; } ?>
<?php $component = App\View\Components\Hero::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Hero::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5)): ?>
<?php $attributes = $__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5; ?>
<?php unset($__attributesOriginal20742eb2771d985bdc9eeee85f5ff6b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5)): ?>
<?php $component = $__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5; ?>
<?php unset($__componentOriginal20742eb2771d985bdc9eeee85f5ff6b5); ?>
<?php endif; ?>
    </section>
    <section class="h-screen snap-start">
        <?php if (isset($component)) { $__componentOriginal84017f13ec2151f374e46d2db1d50fb9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84017f13ec2151f374e46d2db1d50fb9 = $attributes; } ?>
<?php $component = App\View\Components\Sambutan::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sambutan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sambutan::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84017f13ec2151f374e46d2db1d50fb9)): ?>
<?php $attributes = $__attributesOriginal84017f13ec2151f374e46d2db1d50fb9; ?>
<?php unset($__attributesOriginal84017f13ec2151f374e46d2db1d50fb9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84017f13ec2151f374e46d2db1d50fb9)): ?>
<?php $component = $__componentOriginal84017f13ec2151f374e46d2db1d50fb9; ?>
<?php unset($__componentOriginal84017f13ec2151f374e46d2db1d50fb9); ?>
<?php endif; ?>
    </section>
    <section class="h-screen snap-start">
        <?php if (isset($component)) { $__componentOriginal824d60dd2bbe0feda8a3224e3b69600f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal824d60dd2bbe0feda8a3224e3b69600f = $attributes; } ?>
<?php $component = App\View\Components\Fitur::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('fitur'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Fitur::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal824d60dd2bbe0feda8a3224e3b69600f)): ?>
<?php $attributes = $__attributesOriginal824d60dd2bbe0feda8a3224e3b69600f; ?>
<?php unset($__attributesOriginal824d60dd2bbe0feda8a3224e3b69600f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal824d60dd2bbe0feda8a3224e3b69600f)): ?>
<?php $component = $__componentOriginal824d60dd2bbe0feda8a3224e3b69600f; ?>
<?php unset($__componentOriginal824d60dd2bbe0feda8a3224e3b69600f); ?>
<?php endif; ?>
    </section>
    <section class="h-screen snap-start">
        <?php if (isset($component)) { $__componentOriginalc27c6f884d4927a484f37859ef4a439a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc27c6f884d4927a484f37859ef4a439a = $attributes; } ?>
<?php $component = App\View\Components\Materi::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('materi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Materi::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc27c6f884d4927a484f37859ef4a439a)): ?>
<?php $attributes = $__attributesOriginalc27c6f884d4927a484f37859ef4a439a; ?>
<?php unset($__attributesOriginalc27c6f884d4927a484f37859ef4a439a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc27c6f884d4927a484f37859ef4a439a)): ?>
<?php $component = $__componentOriginalc27c6f884d4927a484f37859ef4a439a; ?>
<?php unset($__componentOriginalc27c6f884d4927a484f37859ef4a439a); ?>
<?php endif; ?>
    </section>
    <section class="h-screen snap-start">
        <?php if (isset($component)) { $__componentOriginalc83fc206b16d6ea8359efe8bb375cdf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc83fc206b16d6ea8359efe8bb375cdf2 = $attributes; } ?>
<?php $component = App\View\Components\Tugas::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tugas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tugas::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc83fc206b16d6ea8359efe8bb375cdf2)): ?>
<?php $attributes = $__attributesOriginalc83fc206b16d6ea8359efe8bb375cdf2; ?>
<?php unset($__attributesOriginalc83fc206b16d6ea8359efe8bb375cdf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc83fc206b16d6ea8359efe8bb375cdf2)): ?>
<?php $component = $__componentOriginalc83fc206b16d6ea8359efe8bb375cdf2; ?>
<?php unset($__componentOriginalc83fc206b16d6ea8359efe8bb375cdf2); ?>
<?php endif; ?>
    </section>
    <section class="h-screen snap-start">
        <?php if (isset($component)) { $__componentOriginal500dc3fddd9adeee9a97f32dbe0a4e80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal500dc3fddd9adeee9a97f32dbe0a4e80 = $attributes; } ?>
<?php $component = App\View\Components\Ujian::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ujian'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Ujian::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal500dc3fddd9adeee9a97f32dbe0a4e80)): ?>
<?php $attributes = $__attributesOriginal500dc3fddd9adeee9a97f32dbe0a4e80; ?>
<?php unset($__attributesOriginal500dc3fddd9adeee9a97f32dbe0a4e80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal500dc3fddd9adeee9a97f32dbe0a4e80)): ?>
<?php $component = $__componentOriginal500dc3fddd9adeee9a97f32dbe0a4e80; ?>
<?php unset($__componentOriginal500dc3fddd9adeee9a97f32dbe0a4e80); ?>
<?php endif; ?>
    </section>
    <section class="snap-start">
        <?php if (isset($component)) { $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa = $attributes; } ?>
<?php $component = App\View\Components\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $attributes = $__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__attributesOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa)): ?>
<?php $component = $__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa; ?>
<?php unset($__componentOriginal99051027c5120c83a2f9a5ae7c4c3cfa); ?>
<?php endif; ?>
    </section>
</div>
<?php /**PATH C:\Users\axioo\Desktop\laravel-ap\aplikasi_lms\resources\views/livewire/beranda.blade.php ENDPATH**/ ?>