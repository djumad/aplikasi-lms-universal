<div class="min-h-screen bg-gray-100 flex flex-col p-4">
    
    <div
        id="chat-container"
        class="flex-grow overflow-auto space-y-4 mb-24 px-2"
        style="scroll-behavior: smooth;"
    >
        
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--[if BLOCK]><![endif]--><?php if($message['role'] === 'assistant'): ?>
                
                <div class="max-w-xl bg-gray-200 text-gray-900 rounded-xl px-4 py-3 shadow-md prose prose-sm prose-blue">
                    <?php echo $message['content']; ?>

                </div>
            <?php else: ?>
                
                <div class="max-w-xl ml-auto bg-blue-600 text-white rounded-xl px-4 py-3 shadow-md break-words">
                    <?php echo e($message['content']); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        
        
        <!--[if BLOCK]><![endif]--><?php if($loading): ?>
            <div class="max-w-xl bg-gray-200 text-gray-900 rounded-xl px-4 py-3 shadow-md">
                <div class="flex space-x-2">
                    <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                    <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
                    <div class="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <form wire:submit.prevent="askGemini"
          class="fixed bottom-4 left-4 right-4 bg-white shadow-lg rounded-lg border p-4 flex items-center space-x-2">
        <input
            type="text"
            wire:model="input"
            wire:loading.attr="disabled"
            class="flex-grow rounded border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
            placeholder="Tanya Gemini..."
            autocomplete="off"
            <?php if($loading): ?> disabled <?php endif; ?>
        />
        <button
            type="submit"
            wire:loading.attr="disabled"
            class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded shadow disabled:opacity-50"
            <?php if($loading): ?> disabled <?php endif; ?>
        >
            <span wire:loading.remove>Kirim</span>
            <span wire:loading>
                <svg class="animate-spin -ml-1 mr-1 h-4 w-4 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
            </span>
        </button>
    </form>
</div>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/github.min.css">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/@tailwindcss/typography@0.5.7/dist/typography.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    <script>
        document.addEventListener('livewire:load', () => {
            Livewire.hook('message.processed', () => {
                hljs.highlightAll();
                
                // Scroll chat ke bawah setiap update
                const container = document.getElementById('chat-container');
                if(container) {
                    container.scrollTop = container.scrollHeight;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\axioo\Desktop\laravel-ap\aplikasi_lms\resources\views/livewire/chat-gemini.blade.php ENDPATH**/ ?>