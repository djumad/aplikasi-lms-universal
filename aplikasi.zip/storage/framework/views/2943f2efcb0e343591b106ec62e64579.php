<div x-data class="min-h-screen bg-white px-4 py-6 sm:px-8 md:px-16">

    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold text-blue-600"><?php echo e($ujian->nama); ?></h2>

        <button
            @click="
                try {
                    await document.documentElement.requestFullscreen();
                    document.addEventListener('fullscreenchange', () => {
                        if (!document.fullscreenElement) {
                            window.location.href = '/dashboard/siswa/ujian/<?php echo e($ujian->id); ?>';
                        }
                    });
                } catch(e) {
                    alert('Gagal masuk fullscreen: ' + e.message);
                }
            "
            class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded shadow"
        >
            Masuk Fullscreen
        </button>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded mb-4 shadow">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="simpanJawaban" class="space-y-8">
        
        <div>
            <h3 class="text-lg font-semibold mb-4 text-gray-700">Soal Pilihan Ganda</h3>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ujian->soalPilihanGanda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-6 border p-4 rounded shadow-sm bg-gray-50">
                    <p class="mb-2 text-gray-800 font-medium"><?php echo e($soal->pertanyaan['soal']); ?></p>
                    <div class="space-y-2">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = ['a', 'b', 'c', 'd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $opsiData = $soal->{'opsi_'.$opsi} ?? []; ?>
                            <label class="flex items-start space-x-2">
                                <input
                                    type="radio"
                                    class="mt-1 h-4 w-4 text-blue-600 border-gray-300"
                                    name="pg_<?php echo e($soal->id); ?>"
                                    wire:model="jawabanPg.<?php echo e($soal->id); ?>"
                                    value="<?php echo e($opsiData['nilai'] ?? 0); ?>">
                                <span class="text-gray-700">
                                    <strong><?php echo e(strtoupper($opsi)); ?>.</strong> <?php echo e($opsiData['teks'] ?? ''); ?>

                                    <!--[if BLOCK]><![endif]--><?php if(!empty($opsiData['gambar'])): ?>
                                        <img src="<?php echo e(asset('storage/' . $opsiData['gambar'])); ?>"
                                             class="mt-2 max-h-40 border rounded"
                                             alt="Opsi <?php echo e(strtoupper($opsi)); ?>">
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        
        <div>
            <h3 class="text-lg font-semibold mb-4 text-gray-700">Soal Esai</h3>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ujian->soalEsai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-6 border p-4 rounded shadow-sm bg-gray-50">
                    <p class="mb-2 text-gray-800 font-medium"><?php echo e($soal->pertanyaan); ?></p>
                    <!--[if BLOCK]><![endif]--><?php if($soal->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $soal->foto)); ?>"
                             class="mb-3 max-h-48 border rounded"
                             alt="Gambar soal esai" />
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <textarea wire:model.defer="jawabanEsai.<?php echo e($soal->id); ?>"
                              rows="4"
                              class="w-full rounded border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                              placeholder="Tulis jawaban Anda di sini..."></textarea>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button type="submit"
                class="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded shadow">
            <i class="bi bi-send-check me-1"></i> Kumpulkan
        </button>
    </form>
</div>
<?php /**PATH C:\Users\axioo\Desktop\laravel-ap\aplikasi_lms\resources\views/livewire/ujian-mulai.blade.php ENDPATH**/ ?>