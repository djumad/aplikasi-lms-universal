<?php

namespace App\Filament\Resources\HasilPilihanGandaResource\Pages;

use App\Filament\Resources\HasilPilihanGandaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilPilihanGanda extends CreateRecord
{
    protected static string $resource = HasilPilihanGandaResource::class;
}
