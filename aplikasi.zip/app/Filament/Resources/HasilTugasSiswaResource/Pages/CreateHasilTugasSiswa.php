<?php

namespace App\Filament\Resources\HasilTugasSiswaResource\Pages;

use App\Filament\Resources\HasilTugasSiswaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHasilTugasSiswa extends CreateRecord
{
    protected static string $resource = HasilTugasSiswaResource::class;
}
