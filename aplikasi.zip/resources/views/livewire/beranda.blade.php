<div class="h-screen overflow-y-scroll snap-y snap-mandatory">
    <section class="h-screen snap-start">
        <x-hero />
    </section>
    <section class="h-screen snap-start">
        <x-sambutan />
    </section>
    <section class="h-screen snap-start">
        <x-fitur />
    </section>
    <section class="h-screen snap-start">
        <x-materi />
    </section>
    <section class="h-screen snap-start">
        <x-tugas />
    </section>
    <section class="h-screen snap-start">
        <x-ujian />
    </section>
    <section class="snap-start">
        <x-footer />
    </section>
</div>
